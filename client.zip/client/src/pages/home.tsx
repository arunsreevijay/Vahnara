import { useEffect, useRef, useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { useToast } from "@/hooks/use-toast";
import { useMutation } from "@tanstack/react-query";
import { apiRequest } from "@/lib/queryClient";
import { 
  Compass, 
  Users, 
  Zap, 
  Target, 
  MapPin, 
  Heart, 
  Footprints,
  Trophy,
  Sparkles,
  Radio,
  Eye,
  MessageCircle,
  Play,
  ChevronDown,
  Globe,
  Shield,
  Star
} from "lucide-react";
import { SiDiscord, SiYoutube, SiInstagram, SiWhatsapp } from "react-icons/si";

function ParticleCanvas() {
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;

    const ctx = canvas.getContext("2d");
    if (!ctx) return;

    let animationId: number;
    let particles: Array<{
      x: number;
      y: number;
      size: number;
      speedX: number;
      speedY: number;
      opacity: number;
      twinkleSpeed: number;
      twinkleOffset: number;
    }> = [];

    const resizeCanvas = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };

    const createParticles = () => {
      particles = [];
      const numParticles = Math.floor((canvas.width * canvas.height) / 8000);
      
      for (let i = 0; i < numParticles; i++) {
        particles.push({
          x: Math.random() * canvas.width,
          y: Math.random() * canvas.height,
          size: Math.random() * 2 + 0.5,
          speedX: (Math.random() - 0.5) * 0.3,
          speedY: (Math.random() - 0.5) * 0.3,
          opacity: Math.random() * 0.8 + 0.2,
          twinkleSpeed: Math.random() * 0.02 + 0.01,
          twinkleOffset: Math.random() * Math.PI * 2,
        });
      }
    };

    const animate = () => {
      ctx.clearRect(0, 0, canvas.width, canvas.height);
      
      const time = Date.now() * 0.001;

      particles.forEach((particle) => {
        particle.x += particle.speedX;
        particle.y += particle.speedY;

        if (particle.x < 0) particle.x = canvas.width;
        if (particle.x > canvas.width) particle.x = 0;
        if (particle.y < 0) particle.y = canvas.height;
        if (particle.y > canvas.height) particle.y = 0;

        const twinkle = Math.sin(time * particle.twinkleSpeed * 10 + particle.twinkleOffset) * 0.5 + 0.5;
        const currentOpacity = particle.opacity * (0.5 + twinkle * 0.5);

        const gradient = ctx.createRadialGradient(
          particle.x, particle.y, 0,
          particle.x, particle.y, particle.size * 2
        );
        
        const isCyan = Math.random() > 0.7;
        const color = isCyan ? "0, 229, 255" : "123, 75, 255";
        
        gradient.addColorStop(0, `rgba(${color}, ${currentOpacity})`);
        gradient.addColorStop(0.5, `rgba(${color}, ${currentOpacity * 0.5})`);
        gradient.addColorStop(1, `rgba(${color}, 0)`);

        ctx.beginPath();
        ctx.arc(particle.x, particle.y, particle.size * 2, 0, Math.PI * 2);
        ctx.fillStyle = gradient;
        ctx.fill();
      });

      animationId = requestAnimationFrame(animate);
    };

    const handleResize = () => {
      resizeCanvas();
      createParticles();
    };

    resizeCanvas();
    createParticles();
    animate();

    window.addEventListener("resize", handleResize);

    return () => {
      cancelAnimationFrame(animationId);
      window.removeEventListener("resize", handleResize);
    };
  }, []);

  return (
    <canvas
      ref={canvasRef}
      className="absolute inset-0 pointer-events-none"
      style={{ zIndex: 1 }}
    />
  );
}

function NebulaBackground() {
  return (
    <div className="absolute inset-0 overflow-hidden">
      <div 
        className="absolute inset-0 opacity-30"
        style={{
          background: `
            radial-gradient(ellipse 80% 50% at 20% 40%, rgba(123, 75, 255, 0.15) 0%, transparent 50%),
            radial-gradient(ellipse 60% 40% at 80% 60%, rgba(0, 229, 255, 0.1) 0%, transparent 50%),
            radial-gradient(ellipse 100% 80% at 50% 100%, rgba(123, 75, 255, 0.1) 0%, transparent 40%)
          `,
        }}
      />
      <div 
        className="absolute inset-0 animate-nebula-flow opacity-20"
        style={{
          backgroundSize: "400% 400%",
          background: `
            linear-gradient(45deg, 
              transparent 0%, 
              rgba(123, 75, 255, 0.05) 25%, 
              transparent 50%, 
              rgba(0, 229, 255, 0.05) 75%, 
              transparent 100%
            )
          `,
        }}
      />
    </div>
  );
}

function GlowingOrb() {
  return (
    <div className="relative w-64 h-64 md:w-80 md:h-80 mx-auto">
      <div className="absolute inset-0 animate-rotate-slow">
        <div 
          className="absolute inset-4 rounded-full"
          style={{
            background: "conic-gradient(from 0deg, #7B4BFF, #00E5FF, #7B4BFF)",
            opacity: 0.3,
            filter: "blur(20px)",
          }}
        />
      </div>
      <div className="absolute inset-0 flex items-center justify-center">
        <div 
          className="w-40 h-40 md:w-52 md:h-52 rounded-full animate-pulse-glow relative"
          style={{
            background: "radial-gradient(circle at 30% 30%, #00E5FF, #7B4BFF 50%, #3d1f7a)",
            boxShadow: "0 0 60px rgba(0, 229, 255, 0.5), 0 0 100px rgba(123, 75, 255, 0.3), inset 0 0 60px rgba(0, 229, 255, 0.2)",
          }}
        >
          <div 
            className="absolute inset-0 rounded-full"
            style={{
              background: "linear-gradient(135deg, rgba(255,255,255,0.3) 0%, transparent 50%)",
            }}
          />
          <div className="absolute inset-0 flex items-center justify-center">
            <span className="font-display text-2xl md:text-3xl font-bold text-white/90 tracking-wider">VCI</span>
          </div>
        </div>
      </div>
      <div 
        className="absolute inset-0 animate-energy-pulse rounded-full"
        style={{
          border: "2px solid rgba(0, 229, 255, 0.3)",
        }}
      />
      <div 
        className="absolute -inset-4 animate-energy-pulse rounded-full"
        style={{
          border: "1px solid rgba(123, 75, 255, 0.2)",
          animationDelay: "0.5s",
        }}
      />
    </div>
  );
}

function GlyphIcon({ children, className = "" }: { children: React.ReactNode; className?: string }) {
  return (
    <div className={`relative w-16 h-16 flex items-center justify-center ${className}`}>
      <div 
        className="absolute inset-0 rounded-full opacity-20"
        style={{
          background: "linear-gradient(135deg, #7B4BFF, #00E5FF)",
        }}
      />
      <div className="relative text-[#00E5FF]">
        {children}
      </div>
    </div>
  );
}

function FeatureCard({ 
  icon: Icon, 
  title, 
  description,
  delay = 0 
}: { 
  icon: React.ElementType; 
  title: string; 
  description: string;
  delay?: number;
}) {
  return (
    <Card 
      className="group relative overflow-visible bg-card/50 backdrop-blur-sm border-[#7B4BFF]/20 p-6 transition-all duration-500 hover:border-[#00E5FF]/50 hover:bg-card/80"
      style={{ animationDelay: `${delay}ms` }}
      data-testid={`card-feature-${title.toLowerCase().replace(/\s+/g, '-')}`}
    >
      <div 
        className="absolute inset-0 rounded-md opacity-0 group-hover:opacity-100 transition-opacity duration-500"
        style={{
          background: "linear-gradient(135deg, rgba(123, 75, 255, 0.05) 0%, rgba(0, 229, 255, 0.05) 100%)",
        }}
      />
      <div className="relative z-10">
        <div className="w-12 h-12 rounded-md bg-gradient-to-br from-[#7B4BFF]/20 to-[#00E5FF]/20 flex items-center justify-center mb-4 group-hover:from-[#7B4BFF]/30 group-hover:to-[#00E5FF]/30 transition-all duration-300">
          <Icon className="w-6 h-6 text-[#00E5FF] group-hover:text-[#00E5FF] transition-colors" />
        </div>
        <h3 className="font-display text-lg font-semibold text-white mb-2">{title}</h3>
        <p className="text-muted-foreground text-sm leading-relaxed">{description}</p>
      </div>
    </Card>
  );
}

function VCIFeatureItem({ icon: Icon, title, description }: { icon: React.ElementType; title: string; description: string }) {
  return (
    <div className="flex items-start gap-4 group" data-testid={`vci-feature-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <div className="w-10 h-10 rounded-md bg-gradient-to-br from-[#7B4BFF]/20 to-[#00E5FF]/20 flex items-center justify-center flex-shrink-0 group-hover:from-[#7B4BFF]/30 group-hover:to-[#00E5FF]/30 transition-all duration-300">
        <Icon className="w-5 h-5 text-[#00E5FF]" />
      </div>
      <div>
        <h4 className="font-display text-sm font-semibold text-white mb-1">{title}</h4>
        <p className="text-muted-foreground text-sm">{description}</p>
      </div>
    </div>
  );
}

function LoreSymbol({ symbol, title }: { symbol: React.ReactNode; title: string }) {
  return (
    <div className="flex flex-col items-center gap-3 group" data-testid={`lore-symbol-${title.toLowerCase().replace(/\s+/g, '-')}`}>
      <div 
        className="w-20 h-20 rounded-full flex items-center justify-center border border-[#7B4BFF]/30 group-hover:border-[#00E5FF]/50 transition-all duration-300 group-hover:shadow-neon-cyan"
        style={{
          background: "linear-gradient(135deg, rgba(123, 75, 255, 0.1) 0%, rgba(0, 229, 255, 0.05) 100%)",
        }}
      >
        <div className="text-[#00E5FF] group-hover:text-[#00E5FF] transition-colors">
          {symbol}
        </div>
      </div>
      <span className="font-display text-xs text-muted-foreground uppercase tracking-widest">{title}</span>
    </div>
  );
}

function SocialButton({ icon: Icon, label, href }: { icon: React.ElementType; label: string; href: string }) {
  return (
    <a 
      href={href} 
      target="_blank" 
      rel="noopener noreferrer"
      className="group"
      data-testid={`link-social-${label.toLowerCase()}`}
    >
      <Button 
        variant="outline" 
        size="lg"
        className="gap-2 border-[#7B4BFF]/30 hover:border-[#00E5FF]/50 hover:bg-[#7B4BFF]/10 transition-all duration-300"
      >
        <Icon className="w-5 h-5 text-[#00E5FF]" />
        <span className="text-white">{label}</span>
      </Button>
    </a>
  );
}

export default function Home() {
  const { toast } = useToast();
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    location: "",
  });
  const [submitted, setSubmitted] = useState(false);

  const signupMutation = useMutation({
    mutationFn: async (data: { name: string; email: string; location: string }) => {
      const response = await apiRequest("POST", "/api/early-access", data);
      return response.json();
    },
    onSuccess: () => {
      setSubmitted(true);
      toast({
        title: "Welcome, Pathfinder!",
        description: "You've successfully joined the early access list.",
      });
    },
    onError: (error: Error) => {
      toast({
        title: "Registration Failed",
        description: error.message || "Please try again later.",
        variant: "destructive",
      });
    },
  });

  const scrollToSection = (id: string) => {
    const element = document.getElementById(id);
    if (element) {
      element.scrollIntoView({ behavior: "smooth" });
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    signupMutation.mutate(formData);
  };

  return (
    <div className="min-h-screen bg-[#05050A] text-white overflow-x-hidden">
      <section 
        id="hero" 
        className="relative min-h-screen flex flex-col items-center justify-center px-4"
        data-testid="section-hero"
      >
        <NebulaBackground />
        <ParticleCanvas />
        
        <div className="relative z-10 text-center max-w-4xl mx-auto">
          <div className="mb-6">
            <span className="font-display text-sm md:text-base uppercase tracking-[0.3em] text-[#00E5FF]/80">
              The AR Exploration Universe
            </span>
          </div>
          
          <h1 
            className="font-display text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight animate-glow-pulse"
            style={{
              textShadow: "0 0 40px rgba(0, 229, 255, 0.5), 0 0 80px rgba(123, 75, 255, 0.3)",
            }}
            data-testid="text-hero-headline"
          >
            Follow your path.<br />
            <span className="bg-gradient-to-r from-[#7B4BFF] to-[#00E5FF] bg-clip-text text-transparent">
              Vahnara will do the rest.
            </span>
          </h1>
          
          <p className="text-lg md:text-xl text-white/70 mb-10 max-w-2xl mx-auto font-body leading-relaxed" data-testid="text-hero-subtext">
            A real-world adventure universe where discovery, connection, and destiny collide.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center">
            <Button 
              size="lg"
              className="bg-gradient-to-r from-[#7B4BFF] to-[#7B4BFF] hover:from-[#8B5BFF] hover:to-[#8B5BFF] text-white font-display font-semibold px-8 py-6 text-lg shadow-neon-purple transition-all duration-300"
              onClick={() => scrollToSection("signup")}
              data-testid="button-join-early-access"
            >
              <Sparkles className="w-5 h-5 mr-2" />
              Join Early Access
            </Button>
            <Button 
              size="lg"
              variant="outline"
              className="border-[#00E5FF]/50 text-[#00E5FF] hover:bg-[#00E5FF]/10 hover:border-[#00E5FF] font-display font-semibold px-8 py-6 text-lg backdrop-blur-sm transition-all duration-300"
              data-testid="button-watch-trailer"
            >
              <Play className="w-5 h-5 mr-2" />
              Watch Trailer
            </Button>
          </div>
        </div>
        
        <button 
          onClick={() => scrollToSection("about")}
          className="absolute bottom-8 left-1/2 -translate-x-1/2 text-white/50 hover:text-[#00E5FF] transition-colors animate-float cursor-pointer"
          aria-label="Scroll down"
          data-testid="button-scroll-down"
        >
          <ChevronDown className="w-8 h-8" />
        </button>
      </section>

      <section 
        id="about" 
        className="relative py-24 md:py-32 px-4"
        data-testid="section-about"
      >
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <span className="font-display text-sm uppercase tracking-[0.2em] text-[#7B4BFF] mb-4 block">About Vahnara</span>
              <h2 className="font-display text-3xl md:text-4xl font-bold text-white mb-6" data-testid="text-about-headline">
                The Universe Awaits<br />
                <span className="text-[#00E5FF]">In Your Pocket</span>
              </h2>
              <p className="text-white/70 text-lg leading-relaxed mb-6 font-body">
                Vahnara is a revolutionary AR universe blending real-world exploration with immersive lore, social quests, creature encounters, and player-driven raids. Step outside, and the world transforms.
              </p>
              <p className="text-white/70 leading-relaxed mb-8 font-body">
                Every street corner holds secrets. Every park hides mysteries. Every encounter is a chance to forge bonds that transcend the digital realm.
              </p>
              <blockquote 
                className="border-l-2 border-[#7B4BFF] pl-6 italic text-xl text-white/80 font-body"
                data-testid="text-about-quote"
              >
                "In Vahnara, the only wrong path… is the one you never walk."
              </blockquote>
            </div>
            <div className="relative">
              <div 
                className="absolute inset-0 rounded-2xl opacity-50"
                style={{
                  background: "radial-gradient(circle at center, rgba(123, 75, 255, 0.2) 0%, transparent 70%)",
                }}
              />
              <div className="relative aspect-square rounded-2xl border border-[#7B4BFF]/20 overflow-hidden flex items-center justify-center bg-gradient-to-br from-[#7B4BFF]/5 to-[#00E5FF]/5">
                <div className="grid grid-cols-3 gap-8 p-8">
                  <GlyphIcon><Compass className="w-8 h-8" /></GlyphIcon>
                  <GlyphIcon><Globe className="w-8 h-8" /></GlyphIcon>
                  <GlyphIcon><Star className="w-8 h-8" /></GlyphIcon>
                  <GlyphIcon><Zap className="w-8 h-8" /></GlyphIcon>
                  <GlyphIcon><Shield className="w-8 h-8" /></GlyphIcon>
                  <GlyphIcon><Heart className="w-8 h-8" /></GlyphIcon>
                  <GlyphIcon><Users className="w-8 h-8" /></GlyphIcon>
                  <GlyphIcon><Target className="w-8 h-8" /></GlyphIcon>
                  <GlyphIcon><Eye className="w-8 h-8" /></GlyphIcon>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section 
        id="lore" 
        className="relative py-24 md:py-32 px-4"
        style={{
          background: "linear-gradient(180deg, transparent 0%, rgba(123, 75, 255, 0.03) 50%, transparent 100%)",
        }}
        data-testid="section-lore"
      >
        <div className="max-w-6xl mx-auto text-center">
          <span className="font-display text-sm uppercase tracking-[0.2em] text-[#00E5FF] mb-4 block">The World</span>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-white mb-6" data-testid="text-lore-headline">
            An Ancient Energy Network<br />
            <span className="text-[#7B4BFF]">Hidden in Our World</span>
          </h2>
          <p className="text-white/70 text-lg leading-relaxed mb-16 max-w-3xl mx-auto font-body">
            Beneath the surface of everyday reality flows Vahnara - a cosmic energy grid connecting all living things. Those who can sense it become Pathfinders, guardians of balance between worlds.
          </p>
          
          <div className="grid grid-cols-3 md:grid-cols-6 gap-8 mb-16">
            <LoreSymbol symbol={<Compass className="w-8 h-8" />} title="Pathfinders" />
            <LoreSymbol symbol={<Zap className="w-8 h-8" />} title="Energy" />
            <LoreSymbol symbol={<Shield className="w-8 h-8" />} title="Guardians" />
            <LoreSymbol symbol={<Star className="w-8 h-8" />} title="Celestials" />
            <LoreSymbol symbol={<Globe className="w-8 h-8" />} title="Realms" />
            <LoreSymbol symbol={<Eye className="w-8 h-8" />} title="Watchers" />
          </div>
          
          <Card className="bg-card/30 backdrop-blur-sm border-[#7B4BFF]/20 p-8 max-w-2xl mx-auto">
            <p className="text-white/60 text-sm font-body">
              <span className="text-[#00E5FF]">Coming Soon:</span> Discover the creatures, factions, and cosmic forces that shape the Vahnara universe. Each with unique abilities, alliances, and mysteries to uncover.
            </p>
          </Card>
        </div>
      </section>

      <section 
        id="vci" 
        className="relative py-24 md:py-32 px-4"
        data-testid="section-vci"
      >
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <span className="font-display text-sm uppercase tracking-[0.2em] text-[#7B4BFF] mb-4 block">The Device</span>
            <h2 className="font-display text-3xl md:text-4xl font-bold text-white mb-6" data-testid="text-vci-headline">
              Introducing the <span className="text-[#00E5FF]">VCI</span>
            </h2>
            <p className="text-white/70 text-lg max-w-2xl mx-auto font-body">
              Your companion device for exploring the Vahnara universe. A fusion of cutting-edge technology and ancient cosmic design.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <GlowingOrb />
            
            <div className="space-y-6">
              <VCIFeatureItem 
                icon={Radio}
                title="Real-World Detection"
                description="Advanced sensors detect Vahnara energy signatures in your environment, guiding you to hidden locations and encounters."
              />
              <VCIFeatureItem 
                icon={Zap}
                title="Haptic Feedback & Light Signals"
                description="Feel the pulse of discovery. The VCI responds with vibrations and illumination patterns as you approach points of interest."
              />
              <VCIFeatureItem 
                icon={MessageCircle}
                title="Social Proximity Alerts"
                description="'A friend approaches…' Connect with fellow Pathfinders nearby. Form bonds, plan raids, share discoveries."
              />
              <VCIFeatureItem 
                icon={Eye}
                title="AR Creature Interactions"
                description="See creatures materialize through your device. Observe their behaviors, earn their trust, and add them to your constellation."
              />
              
              <Button 
                size="lg"
                className="w-full sm:w-auto mt-8 bg-gradient-to-r from-[#00E5FF] to-[#00E5FF] hover:from-[#00E5FF]/90 hover:to-[#00E5FF]/90 text-[#05050A] font-display font-semibold px-8 py-6 text-lg shadow-neon-cyan transition-all duration-300"
                onClick={() => scrollToSection("signup")}
                data-testid="button-vci-waitlist"
              >
                Join VCI Waitlist
              </Button>
            </div>
          </div>
        </div>
      </section>

      <section 
        id="features" 
        className="relative py-24 md:py-32 px-4"
        style={{
          background: "linear-gradient(180deg, transparent 0%, rgba(0, 229, 255, 0.02) 50%, transparent 100%)",
        }}
        data-testid="section-features"
      >
        <div className="max-w-6xl mx-auto">
          <div className="text-center mb-16">
            <span className="font-display text-sm uppercase tracking-[0.2em] text-[#00E5FF] mb-4 block">Gameplay</span>
            <h2 className="font-display text-3xl md:text-4xl font-bold text-white mb-6" data-testid="text-features-headline">
              Features That <span className="text-[#7B4BFF]">Transform Reality</span>
            </h2>
            <p className="text-white/70 text-lg max-w-2xl mx-auto font-body">
              Every feature designed to get you outside, exploring, and connecting with the world around you.
            </p>
          </div>
          
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            <FeatureCard 
              icon={Compass}
              title="Real-World Exploration"
              description="Your neighborhood becomes a canvas of adventure. Parks, landmarks, and hidden spots transform into discovery zones."
              delay={0}
            />
            <FeatureCard 
              icon={Users}
              title="Raids & Group Missions"
              description="Team up with nearby players for epic encounters. Strategy, coordination, and shared triumph await."
              delay={100}
            />
            <FeatureCard 
              icon={Heart}
              title="Social Encounters"
              description="Meet fellow Pathfinders in the real world. Form lasting connections that extend beyond the game."
              delay={200}
            />
            <FeatureCard 
              icon={Target}
              title="Daily Quests"
              description="New challenges every day. Keep moving, keep exploring, keep growing your legend."
              delay={300}
            />
            <FeatureCard 
              icon={MapPin}
              title="Territory Zones"
              description="Claim areas, defend your turf, and leave your mark on the world map for all to see."
              delay={400}
            />
            <FeatureCard 
              icon={Footprints}
              title="Fitness Integration"
              description="Steps count. Jogging trails unlock secrets. Your healthy lifestyle powers your in-game progress."
              delay={500}
            />
            <FeatureCard 
              icon={Trophy}
              title="Competitive Events"
              description="Seasonal tournaments, global leaderboards, and exclusive rewards for the most dedicated explorers."
              delay={600}
            />
          </div>
        </div>
      </section>

      <section 
        id="mission" 
        className="relative py-24 md:py-32 px-4"
        data-testid="section-mission"
      >
        <div className="max-w-4xl mx-auto text-center">
          <span className="font-display text-sm uppercase tracking-[0.2em] text-[#7B4BFF] mb-4 block">Our Mission</span>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-white mb-8" data-testid="text-mission-headline">
            A Healthier Way to <span className="text-[#00E5FF]">Connect</span>
          </h2>
          <p className="text-white/70 text-xl leading-relaxed mb-12 font-body">
            Vahnara is built to get people outside, exploring, connecting, and forming real relationships. A healthier alternative to traditional social media - where every interaction happens in the real world.
          </p>
          
          <div className="grid grid-cols-3 gap-8 max-w-lg mx-auto">
            <div className="text-center">
              <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-br from-[#7B4BFF]/20 to-[#00E5FF]/20 flex items-center justify-center mb-4">
                <Users className="w-8 h-8 text-[#00E5FF]" />
              </div>
              <span className="text-sm text-white/70 font-body">Community</span>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-br from-[#7B4BFF]/20 to-[#00E5FF]/20 flex items-center justify-center mb-4">
                <Compass className="w-8 h-8 text-[#00E5FF]" />
              </div>
              <span className="text-sm text-white/70 font-body">Exploration</span>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-br from-[#7B4BFF]/20 to-[#00E5FF]/20 flex items-center justify-center mb-4">
                <Heart className="w-8 h-8 text-[#00E5FF]" />
              </div>
              <span className="text-sm text-white/70 font-body">Unity</span>
            </div>
          </div>
        </div>
      </section>

      <section 
        id="signup" 
        className="relative py-24 md:py-32 px-4"
        style={{
          background: "linear-gradient(180deg, transparent 0%, rgba(123, 75, 255, 0.05) 50%, transparent 100%)",
        }}
        data-testid="section-signup"
      >
        <div className="max-w-xl mx-auto text-center">
          <span className="font-display text-sm uppercase tracking-[0.2em] text-[#00E5FF] mb-4 block">Early Access</span>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-white mb-4" data-testid="text-signup-headline">
            Become a <span className="text-[#7B4BFF]">Pathfinder</span>
          </h2>
          <p className="text-white/70 text-lg mb-8 font-body">
            Join the First Wave. Be among the chosen few to shape the Vahnara universe.
          </p>
          
          {submitted ? (
            <Card className="bg-card/50 backdrop-blur-sm border-[#00E5FF]/30 p-8">
              <div className="text-center">
                <div className="w-16 h-16 mx-auto rounded-full bg-gradient-to-br from-[#7B4BFF] to-[#00E5FF] flex items-center justify-center mb-4">
                  <Sparkles className="w-8 h-8 text-white" />
                </div>
                <h3 className="font-display text-xl font-bold text-white mb-2" data-testid="text-signup-success">Welcome, Pathfinder</h3>
                <p className="text-white/70 font-body">Your journey begins soon. Watch your inbox for cosmic transmissions.</p>
              </div>
            </Card>
          ) : (
            <Card className="bg-card/50 backdrop-blur-sm border-[#7B4BFF]/20 p-8">
              <form onSubmit={handleSubmit} className="space-y-4">
                <Input 
                  type="text"
                  placeholder="Your Name"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  required
                  className="bg-background/50 border-[#7B4BFF]/30 focus:border-[#00E5FF] text-white placeholder:text-white/40"
                  data-testid="input-signup-name"
                />
                <Input 
                  type="email"
                  placeholder="Email Address"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  required
                  className="bg-background/50 border-[#7B4BFF]/30 focus:border-[#00E5FF] text-white placeholder:text-white/40"
                  data-testid="input-signup-email"
                />
                <Input 
                  type="text"
                  placeholder="Location (City, Country)"
                  value={formData.location}
                  onChange={(e) => setFormData({ ...formData, location: e.target.value })}
                  required
                  className="bg-background/50 border-[#7B4BFF]/30 focus:border-[#00E5FF] text-white placeholder:text-white/40"
                  data-testid="input-signup-location"
                />
                <Button 
                  type="submit"
                  size="lg"
                  disabled={signupMutation.isPending}
                  className="w-full bg-gradient-to-r from-[#7B4BFF] to-[#00E5FF] hover:from-[#8B5BFF] hover:to-[#10F5FF] text-white font-display font-semibold py-6 text-lg shadow-neon-glow transition-all duration-300"
                  data-testid="button-signup-submit"
                >
                  {signupMutation.isPending ? (
                    <span className="flex items-center gap-2">
                      <div className="w-5 h-5 border-2 border-white/30 border-t-white rounded-full animate-spin" />
                      Initiating...
                    </span>
                  ) : (
                    <>
                      <Sparkles className="w-5 h-5 mr-2" />
                      Begin Your Journey
                    </>
                  )}
                </Button>
              </form>
            </Card>
          )}
        </div>
      </section>

      <section 
        id="community" 
        className="relative py-24 md:py-32 px-4"
        data-testid="section-community"
      >
        <div className="max-w-4xl mx-auto text-center">
          <span className="font-display text-sm uppercase tracking-[0.2em] text-[#7B4BFF] mb-4 block">Community</span>
          <h2 className="font-display text-3xl md:text-4xl font-bold text-white mb-8" data-testid="text-community-headline">
            Join the <span className="text-[#00E5FF]">Pathfinder Network</span>
          </h2>
          <p className="text-white/70 text-lg mb-12 font-body">
            Connect with fellow explorers. Share discoveries. Shape the future of Vahnara together.
          </p>
          
          <div className="flex flex-wrap justify-center gap-4">
            <SocialButton icon={SiDiscord} label="Discord" href="#" />
            <SocialButton icon={SiYoutube} label="YouTube" href="#" />
            <SocialButton icon={SiInstagram} label="Instagram" href="#" />
            <SocialButton icon={SiWhatsapp} label="WhatsApp" href="#" />
          </div>
        </div>
      </section>

      <footer 
        className="relative py-16 px-4 border-t border-[#7B4BFF]/20"
        data-testid="section-footer"
      >
        <div className="max-w-6xl mx-auto">
          <div className="flex flex-col md:flex-row justify-between items-center gap-8">
            <div className="text-center md:text-left">
              <h3 className="font-display text-2xl font-bold text-white mb-2">VAHNARA</h3>
              <p className="text-white/50 text-sm font-body">Follow your path. The universe awaits.</p>
            </div>
            
            <div className="flex flex-wrap justify-center gap-6 text-sm">
              <a href="#" className="text-white/50 hover:text-[#00E5FF] transition-colors" data-testid="link-privacy">Privacy Policy</a>
              <a href="#" className="text-white/50 hover:text-[#00E5FF] transition-colors" data-testid="link-terms">Terms of Service</a>
              <a href="#" className="text-white/50 hover:text-[#00E5FF] transition-colors" data-testid="link-contact">Contact</a>
            </div>
          </div>
          
          <div className="mt-12 pt-8 border-t border-[#7B4BFF]/10 text-center">
            <p className="text-white/30 text-sm font-body">
              © 2024 Vahnara. All rights reserved. The path is yours to walk.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
}
