import { type User, type InsertUser, type EarlyAccess, type InsertEarlyAccess } from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  createEarlyAccessSignup(signup: InsertEarlyAccess): Promise<EarlyAccess>;
  getEarlyAccessByEmail(email: string): Promise<EarlyAccess | undefined>;
  getAllEarlyAccessSignups(): Promise<EarlyAccess[]>;
}

export class MemStorage implements IStorage {
  private users: Map<string, User>;
  private earlyAccessSignups: Map<string, EarlyAccess>;

  constructor() {
    this.users = new Map();
    this.earlyAccessSignups = new Map();
  }

  async getUser(id: string): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async createEarlyAccessSignup(insertSignup: InsertEarlyAccess): Promise<EarlyAccess> {
    const id = randomUUID();
    const signup: EarlyAccess = { ...insertSignup, id };
    this.earlyAccessSignups.set(id, signup);
    return signup;
  }

  async getEarlyAccessByEmail(email: string): Promise<EarlyAccess | undefined> {
    return Array.from(this.earlyAccessSignups.values()).find(
      (signup) => signup.email === email,
    );
  }

  async getAllEarlyAccessSignups(): Promise<EarlyAccess[]> {
    return Array.from(this.earlyAccessSignups.values());
  }
}

export const storage = new MemStorage();
