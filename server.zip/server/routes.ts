import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertEarlyAccessSchema } from "@shared/schema";
import { Resend } from "resend";

const resend = new Resend(process.env.RESEND_API_KEY);
const NOTIFICATION_EMAIL = "vahnaraempire@gmail.com";

async function sendSignupNotification(signup: { name: string; email: string; location: string }) {
  try {
    await resend.emails.send({
      from: "VAHNARA Signups <onboarding@resend.dev>",
      to: NOTIFICATION_EMAIL,
      subject: `New Early Access Signup: ${signup.name}`,
      html: `
        <div style="font-family: 'Segoe UI', Arial, sans-serif; max-width: 600px; margin: 0 auto; background: linear-gradient(135deg, #05050A 0%, #1a1a2e 100%); padding: 40px; border-radius: 16px;">
          <div style="text-align: center; margin-bottom: 30px;">
            <h1 style="color: #00E5FF; font-size: 28px; margin: 0; text-shadow: 0 0 20px rgba(0, 229, 255, 0.5);">VAHNARA</h1>
            <p style="color: #7B4BFF; font-size: 14px; margin: 5px 0 0 0;">New Pathfinder Alert</p>
          </div>
          
          <div style="background: rgba(123, 75, 255, 0.1); border: 1px solid rgba(123, 75, 255, 0.3); border-radius: 12px; padding: 24px; margin-bottom: 20px;">
            <h2 style="color: #ffffff; font-size: 18px; margin: 0 0 20px 0;">Someone wants to join the journey!</h2>
            
            <div style="margin-bottom: 16px;">
              <p style="color: #00E5FF; font-size: 12px; margin: 0; text-transform: uppercase; letter-spacing: 1px;">Name</p>
              <p style="color: #ffffff; font-size: 16px; margin: 4px 0 0 0;">${signup.name}</p>
            </div>
            
            <div style="margin-bottom: 16px;">
              <p style="color: #00E5FF; font-size: 12px; margin: 0; text-transform: uppercase; letter-spacing: 1px;">Email</p>
              <p style="color: #ffffff; font-size: 16px; margin: 4px 0 0 0;"><a href="mailto:${signup.email}" style="color: #7B4BFF; text-decoration: none;">${signup.email}</a></p>
            </div>
            
            <div>
              <p style="color: #00E5FF; font-size: 12px; margin: 0; text-transform: uppercase; letter-spacing: 1px;">Location</p>
              <p style="color: #ffffff; font-size: 16px; margin: 4px 0 0 0;">${signup.location}</p>
            </div>
          </div>
          
          <p style="color: rgba(255, 255, 255, 0.6); font-size: 12px; text-align: center; margin: 0;">
            This notification was sent from your VAHNARA early access signup form.
          </p>
        </div>
      `,
    });
    console.log(`Notification email sent for signup: ${signup.email}`);
  } catch (error) {
    console.error("Failed to send notification email:", error);
  }
}

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  app.post("/api/early-access", async (req, res) => {
    try {
      const result = insertEarlyAccessSchema.safeParse(req.body);
      
      if (!result.success) {
        return res.status(400).json({ 
          message: "Invalid form data", 
          errors: result.error.flatten() 
        });
      }

      const existingSignup = await storage.getEarlyAccessByEmail(result.data.email);
      if (existingSignup) {
        return res.status(409).json({ 
          message: "This email is already registered for early access" 
        });
      }

      const signup = await storage.createEarlyAccessSignup(result.data);
      
      sendSignupNotification(result.data);
      
      return res.status(201).json({ 
        message: "Successfully registered for early access!",
        signup 
      });
    } catch (error) {
      console.error("Early access signup error:", error);
      return res.status(500).json({ 
        message: "An error occurred. Please try again later." 
      });
    }
  });

  app.get("/api/early-access", async (req, res) => {
    try {
      const signups = await storage.getAllEarlyAccessSignups();
      return res.json(signups);
    } catch (error) {
      console.error("Error fetching signups:", error);
      return res.status(500).json({ 
        message: "An error occurred while fetching signups." 
      });
    }
  });

  return httpServer;
}
